# Library Management System (Spring Boot REST API)

A simple REST API to manage books. Data is stored in memory (a `Map`), so no database is needed.
Data is lost when the application stops.

## Tech
- Java 21
- Spring Boot 3.3.5
- Maven

## Project Structure
```
src/main/java/com/college/library
 |-- LibraryManagementSystemApplication.java   (main class)
 |-- model/Book.java
 |-- service/BookService.java
 `-- controller/BookController.java
src/main/resources/application.properties
pom.xml
```

## Run in IntelliJ IDEA
1. Extract the ZIP.
2. File > Open > select the `LibraryManagementSystem` folder (the one containing `pom.xml`).
3. Wait for Maven to download dependencies. Set Project SDK to Java 21 if asked.
4. Open `LibraryManagementSystemApplication.java` and click the green Run button.
5. Server starts at http://localhost:8080

## Run from terminal (optional)
```
mvn spring-boot:run
```

## API Endpoints
| Method | URL               | Description       |
|--------|-------------------|-------------------|
| POST   | /api/books        | Add a new book    |
| GET    | /api/books        | Get all books     |
| GET    | /api/books/{id}   | Get book by id    |
| PUT    | /api/books/{id}   | Update a book     |
| DELETE | /api/books/{id}   | Delete a book     |

A missing book id returns HTTP 404.

## Sample JSON
```json
{
  "title": "Clean Code",
  "author": "Robert C. Martin",
  "category": "Programming",
  "availableCopies": 5
}
```
