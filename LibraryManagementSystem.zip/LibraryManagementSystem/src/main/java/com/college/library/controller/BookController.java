package com.college.library.controller;

import com.college.library.model.Book;
import com.college.library.service.BookService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {

    private final BookService bookService;

    // Constructor injection: Spring gives us the BookService object
    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    // 1. POST /api/books - Add a new book
    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        Book savedBook = bookService.addBook(book);
        return new ResponseEntity<>(savedBook, HttpStatus.CREATED); // 201
    }

    // 2. GET /api/books - Get all books
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        return ResponseEntity.ok(bookService.getAllBooks()); // 200
    }

    // 3. GET /api/books/{id} - Get a book by id
    @GetMapping("/{id}")
    public ResponseEntity<Object> getBookById(@PathVariable Integer id) {
        Book book = bookService.getBookById(id);
        if (book == null) {
            return new ResponseEntity<>("Book not found with id: " + id, HttpStatus.NOT_FOUND); // 404
        }
        return ResponseEntity.ok(book); // 200
    }

    // 4. PUT /api/books/{id} - Update a book
    @PutMapping("/{id}")
    public ResponseEntity<Object> updateBook(@PathVariable Integer id, @RequestBody Book book) {
        Book updatedBook = bookService.updateBook(id, book);
        if (updatedBook == null) {
            return new ResponseEntity<>("Book not found with id: " + id, HttpStatus.NOT_FOUND); // 404
        }
        return ResponseEntity.ok(updatedBook); // 200
    }

    // 5. DELETE /api/books/{id} - Delete a book
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable Integer id) {
        boolean deleted = bookService.deleteBook(id);
        if (!deleted) {
            return new ResponseEntity<>("Book not found with id: " + id, HttpStatus.NOT_FOUND); // 404
        }
        return ResponseEntity.ok("Book deleted successfully"); // 200
    }
}
