package com.college.library.service;

import com.college.library.model.Book;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class BookService {

    // In-memory storage (no database): key = book id, value = Book
    private final Map<Integer, Book> books = new LinkedHashMap<>();

    // Used to generate a new id for every book
    private int nextId = 1;

    // 1. Add a new book
    public Book addBook(Book book) {
        book.setId(nextId++);
        books.put(book.getId(), book);
        return book;
    }

    // 2. Get all books
    public List<Book> getAllBooks() {
        return new ArrayList<>(books.values());
    }

    // 3. Get a book by id (returns null if not found)
    public Book getBookById(Integer id) {
        return books.get(id);
    }

    // 4. Update a book (returns null if not found)
    public Book updateBook(Integer id, Book updatedBook) {
        Book existingBook = books.get(id);
        if (existingBook == null) {
            return null;
        }
        existingBook.setTitle(updatedBook.getTitle());
        existingBook.setAuthor(updatedBook.getAuthor());
        existingBook.setCategory(updatedBook.getCategory());
        existingBook.setAvailableCopies(updatedBook.getAvailableCopies());
        return existingBook;
    }

    // 5. Delete a book (returns true if deleted, false if not found)
    public boolean deleteBook(Integer id) {
        return books.remove(id) != null;
    }
}
